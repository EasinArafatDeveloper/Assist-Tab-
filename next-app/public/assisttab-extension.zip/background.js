// Listen for Chrome alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith('class_alarm_')) {
    try {
      // Name format: class_alarm_[id]_[className]_[room]
      const parts = alarm.name.split('_');
      const className = decodeURIComponent(parts[3] || 'Class');
      const room = decodeURIComponent(parts[4] || '');

      const messageStr = room 
        ? `Your class "${className}" starts in 10 minutes in Room ${room}!` 
        : `Your class "${className}" starts in 10 minutes!`;

      chrome.notifications.create(`reminder-${Date.now()}`, {
        type: 'basic',
        iconUrl: 'icon-128.png', // Fallback to icon-128.png in the same directory
        title: 'Upcoming Class Reminder',
        message: messageStr,
        priority: 2,
        requireInteraction: true // Keeps notification visible until user interacts
      });
    } catch (e) {
      console.error('Error processing class alarm:', e);
    }
  }
});
