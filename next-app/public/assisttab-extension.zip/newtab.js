// Mock chrome.storage if running outside of extension context (e.g. for testing in web browser)
if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
  window.chrome = window.chrome || {};
  chrome.storage = {
    local: {
      get: (keys, callback) => {
        const result = {};
        const keyList = Array.isArray(keys) ? keys : [keys];
        keyList.forEach(key => {
          result[key] = localStorage.getItem(key);
        });
        setTimeout(() => callback(result), 0);
      },
      set: (data, callback) => {
        Object.keys(data).forEach(key => {
          localStorage.setItem(key, data[key]);
        });
        if (callback) setTimeout(callback, 0);
      },
      remove: (keys, callback) => {
        const keyList = Array.isArray(keys) ? keys : [keys];
        keyList.forEach(key => {
          localStorage.removeItem(key);
        });
        if (callback) setTimeout(callback, 0);
      }
    }
  };
}

// Global Application State
let TOKEN = null;
let BACKEND_URL = 'http://localhost:3000';
let USER = null;
let CLASS_SCHEDULE = [];
let CHAT_HISTORY = [
  { role: 'assistant', content: "Hello! I'm your Personal Assistant. I have access to your daily routine checklist and class schedule. How can I help you organize your day today?" }
];
let CURRENT_CLASS_VIEW = 'today'; // 'today' or 'weekly'

// DOM Elements
const authScreen = document.getElementById('auth-screen');
const dashboardScreen = document.getElementById('dashboard-screen');
const authForm = document.getElementById('auth-form');
const authEmail = document.getElementById('auth-email');
const authPassword = document.getElementById('auth-password');
const authSubmitBtn = document.getElementById('auth-submit-btn');
const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');
const backendUrlConfig = document.getElementById('backend-url-config');

const welcomeMessage = document.getElementById('welcome-message');
const liveDate = document.getElementById('live-date');
const liveClock = document.getElementById('live-clock');
const settingsToggleBtn = document.getElementById('settings-toggle-btn');
const settingsPanel = document.getElementById('settings-panel');
const settingsCloseBtn = document.getElementById('settings-close-btn');
const settingsBackendUrl = document.getElementById('settings-backend-url');
const saveSettingsBtn = document.getElementById('save-settings-btn');
const logoutBtn = document.getElementById('logout-btn');

const addRoutineToggle = document.getElementById('add-routine-toggle');
const routineFormContainer = document.getElementById('routine-form-container');
const routineForm = document.getElementById('routine-form');
const routineTitle = document.getElementById('routine-title');
const routineDesc = document.getElementById('routine-desc');
const routineTime = document.getElementById('routine-time');
const routineList = document.getElementById('routine-list');
const importRoutineToggle = document.getElementById('import-routine-toggle');
const importRoutineContainer = document.getElementById('import-routine-container');
const importTabFile = document.getElementById('import-tab-file');
const importTabSheet = document.getElementById('import-tab-sheet');
const importPaneFile = document.getElementById('import-pane-file');
const importPaneSheet = document.getElementById('import-pane-sheet');
const routineFileInput = document.getElementById('routine-file-input');
const fileUploadStatus = document.getElementById('file-upload-status');
const sheetUrlInput = document.getElementById('sheet-url-input');
const processImportBtn = document.getElementById('process-import-btn');

const addClassToggle = document.getElementById('add-class-toggle');
const classFormContainer = document.getElementById('class-form-container');
const classForm = document.getElementById('class-form');
const classNameInput = document.getElementById('class-name');
const classSubjectInput = document.getElementById('class-subject');
const classRoomInput = document.getElementById('class-room');
const classDayInput = document.getElementById('class-day');
const classStartInput = document.getElementById('class-start');
const classEndInput = document.getElementById('class-end');
const classInstructorInput = document.getElementById('class-instructor');
const classList = document.getElementById('class-list');
const viewTodayBtn = document.getElementById('view-today');
const viewWeeklyBtn = document.getElementById('view-weekly');

const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const aiStatus = document.getElementById('ai-status');

// 1. INITIALIZATION & AUTHENTICATION FLOW

document.addEventListener('DOMContentLoaded', async () => {
  // Load configuration from local storage
  chrome.storage.local.get(['jwt_token', 'backend_url'], async (result) => {
    if (result.backend_url) {
      BACKEND_URL = result.backend_url;
      settingsBackendUrl.value = BACKEND_URL;
      backendUrlConfig.value = BACKEND_URL;
    }
    
    if (result.jwt_token) {
      TOKEN = result.jwt_token;
      const verified = await verifyToken();
      if (verified) {
        initDashboard();
      } else {
        showAuthScreen();
      }
    } else {
      showAuthScreen();
    }
  });

  // Start Date & Time Live Clock
  updateDateTime();
  setInterval(updateDateTime, 1000);
});

// Update the Date and Clock
function updateDateTime() {
  const now = new Date();
  
  // Format: "Friday, July 3, 2026"
  const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  liveDate.textContent = now.toLocaleDateString('en-US', dateOptions);
  
  // Format: "18:00:25" or "18:00"
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  liveClock.textContent = `${hours}:${minutes}`;

  // Periodically check if we need to refresh class highlights (e.g. every minute)
  if (now.getSeconds() === 0 && TOKEN) {
    renderClasses();
  }
}

// Check JWT with backend /api/auth/me
async function verifyToken() {
  try {
    const res = await fetch(`${BACKEND_URL}/api/auth/me`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${TOKEN}`
      }
    });

    if (res.ok) {
      const payload = await res.json();
      if (payload.success) {
        USER = payload.data.user;
        return true;
      }
    }
    return false;
  } catch (err) {
    console.error('Failed to verify token:', err);
    return false;
  }
}

function showAuthScreen() {
  authScreen.classList.remove('hidden');
  dashboardScreen.classList.add('hidden');
}

function initDashboard() {
  authScreen.classList.add('hidden');
  dashboardScreen.classList.remove('hidden');
  
  // Personalized welcome
  const emailUsername = USER.email.split('@')[0];
  const capitalizedUser = emailUsername.charAt(0).toUpperCase() + emailUsername.slice(1);
  welcomeMessage.textContent = `Hello, ${capitalizedUser}!`;

  // Fetch Dashboard Content
  fetchRoutines();
  fetchClasses();
}

// Auth Tab Switching (Login vs Register)
let authMode = 'login';

tabLogin.addEventListener('click', () => {
  authMode = 'login';
  tabLogin.classList.add('active');
  tabRegister.classList.remove('active');
  authSubmitBtn.textContent = 'Log In';
});

tabRegister.addEventListener('click', () => {
  authMode = 'register';
  tabRegister.classList.add('active');
  tabLogin.classList.remove('active');
  authSubmitBtn.textContent = 'Register Account';
});

// Submit login/registration
authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = authEmail.value.trim();
  const password = authPassword.value;
  
  // Dynamic backend URL update if user edited connection setting before auth
  if (backendUrlConfig.value.trim()) {
    BACKEND_URL = backendUrlConfig.value.trim();
    chrome.storage.local.set({ backend_url: BACKEND_URL });
  }

  const endpoint = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
  authSubmitBtn.disabled = true;
  authSubmitBtn.textContent = authMode === 'login' ? 'Logging in...' : 'Registering...';

  try {
    const res = await fetch(`${BACKEND_URL}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (res.ok && data.success) {
      TOKEN = data.data.token;
      USER = data.data.user;
      
      // Save credentials locally
      chrome.storage.local.set({ jwt_token: TOKEN }, () => {
        authEmail.value = '';
        authPassword.value = '';
        authSubmitBtn.disabled = false;
        initDashboard();
      });
    } else {
      alert(data.error || 'Authentication failed. Please check your credentials.');
      authSubmitBtn.disabled = false;
      authSubmitBtn.textContent = authMode === 'login' ? 'Log In' : 'Register Account';
    }
  } catch (err) {
    console.error(err);
    alert('Could not connect to the backend server. Make sure it is running.');
    authSubmitBtn.disabled = false;
    authSubmitBtn.textContent = authMode === 'login' ? 'Log In' : 'Register Account';
  }
});

// Logout
function logout() {
  TOKEN = null;
  USER = null;
  chrome.storage.local.remove('jwt_token', () => {
    // Clear alarms on logout if API is available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
      chrome.alarms.clearAll();
    }
    showAuthScreen();
    // Close settings modal if open
    settingsPanel.classList.add('hidden');
  });
}

logoutBtn.addEventListener('click', logout);


// 2. DASHBOARD SETTINGS PANEL

settingsToggleBtn.addEventListener('click', () => {
  settingsBackendUrl.value = BACKEND_URL;
  settingsPanel.classList.remove('hidden');
});

settingsCloseBtn.addEventListener('click', () => {
  settingsPanel.classList.add('hidden');
});

saveSettingsBtn.addEventListener('click', () => {
  const rawUrl = settingsBackendUrl.value.trim();
  if (rawUrl) {
    BACKEND_URL = rawUrl;
    chrome.storage.local.set({ backend_url: BACKEND_URL }, () => {
      settingsPanel.classList.add('hidden');
      // Refresh dashboard with new API URL
      if (TOKEN) {
        initDashboard();
      }
    });
  }
});


// 3. DAILY ROUTINE MODULE

addRoutineToggle.addEventListener('click', () => {
  routineFormContainer.classList.toggle('hidden');
  routineTitle.focus();
});

// Fetch Routines
async function fetchRoutines() {
  try {
    // Send browser timezone offset in minutes to handle server-side calendar-day resets
    const offset = new Date().getTimezoneOffset();
    const res = await fetch(`${BACKEND_URL}/api/routine?offset=${offset}`, {
      headers: { 'Authorization': `Bearer ${TOKEN}` }
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        renderRoutines(data.data);
      }
    }
  } catch (err) {
    console.error('Fetch routines failed:', err);
    routineList.innerHTML = '<div class="loading-placeholder" style="color: var(--danger)">Connection to server lost.</div>';
  }
}

// Render Routines
function renderRoutines(routines) {
  if (routines.length === 0) {
    routineList.innerHTML = '<div class="loading-placeholder">No routine items yet. Click "+" to add one!</div>';
    return;
  }

  routineList.innerHTML = '';
  
  // Sort: incomplete first, then completed. Or maintain order.
  // Let's sort completed items to the bottom of the list for a clean productivity experience
  const sortedRoutines = [...routines].sort((a, b) => {
    if (a.isCompleted === b.isCompleted) {
      return a.order - b.order;
    }
    return a.isCompleted ? 1 : -1;
  });

  sortedRoutines.forEach(routine => {
    const item = document.createElement('div');
    item.className = `routine-item ${routine.isCompleted ? 'completed' : ''}`;
    item.dataset.id = routine._id;

    item.innerHTML = `
      <div class="checkbox-wrapper">
        <input type="checkbox" id="check-${routine._id}" ${routine.isCompleted ? 'checked' : ''}>
        <label for="check-${routine._id}" class="checkmark"></label>
      </div>
      <div class="routine-content">
        <div class="routine-title-row">
          <span class="routine-title">${escapeHTML(routine.title)}</span>
          ${routine.time ? `<span class="routine-time-badge">${routine.time}</span>` : ''}
        </div>
        ${routine.description ? `<p class="routine-desc">${escapeHTML(routine.description)}</p>` : ''}
      </div>
      <button class="delete-action-btn" title="Delete Routine">🗑️</button>
    `;

    // Hook Checkbox Change
    const checkbox = item.querySelector('input[type="checkbox"]');
    checkbox.addEventListener('change', async (e) => {
      const isCompleted = e.target.checked;
      item.classList.toggle('completed', isCompleted);
      
      try {
        const res = await fetch(`${BACKEND_URL}/api/routine/${routine._id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${TOKEN}`
          },
          body: JSON.stringify({ isCompleted })
        });
        
        if (res.ok) {
          // Re-fetch to apply visual sort
          fetchRoutines();
        } else {
          // Revert checkbox state on error
          checkbox.checked = !isCompleted;
          item.classList.toggle('completed', !isCompleted);
        }
      } catch (err) {
        console.error('Update routine failed:', err);
        checkbox.checked = !isCompleted;
        item.classList.toggle('completed', !isCompleted);
      }
    });

    // Hook Delete Button
    const deleteBtn = item.querySelector('.delete-action-btn');
    deleteBtn.addEventListener('click', async () => {
      if (confirm(`Delete routine "${routine.title}"?`)) {
        try {
          const res = await fetch(`${BACKEND_URL}/api/routine/${routine._id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${TOKEN}` }
          });
          if (res.ok) {
            fetchRoutines();
          }
        } catch (err) {
          console.error(err);
        }
      }
    });

    routineList.appendChild(item);
  });
}

// Add New Routine
routineForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = routineTitle.value.trim();
  const description = routineDesc.value.trim();
  const time = routineTime.value;

  if (!title) return;

  try {
    const res = await fetch(`${BACKEND_URL}/api/routine`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({ title, description, time })
    });

    if (res.ok) {
      // Clear and hide form
      routineTitle.value = '';
      routineDesc.value = '';
      routineTime.value = '';
      routineFormContainer.classList.add('hidden');
      
      fetchRoutines();
    }
  } catch (err) {
    console.error('Create routine failed:', err);
  }
});


// 4. CLASS SCHEDULE MODULE

addClassToggle.addEventListener('click', () => {
  classFormContainer.classList.toggle('hidden');
  classNameInput.focus();
});

viewTodayBtn.addEventListener('click', () => {
  CURRENT_CLASS_VIEW = 'today';
  viewTodayBtn.classList.add('active');
  viewWeeklyBtn.classList.remove('active');
  renderClasses();
});

viewWeeklyBtn.addEventListener('click', () => {
  CURRENT_CLASS_VIEW = 'weekly';
  viewWeeklyBtn.classList.add('active');
  viewTodayBtn.classList.remove('active');
  renderClasses();
});

// Fetch Classes
async function fetchClasses() {
  try {
    const res = await fetch(`${BACKEND_URL}/api/class`, {
      headers: { 'Authorization': `Bearer ${TOKEN}` }
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        CLASS_SCHEDULE = data.data;
        renderClasses();
        // Sync desktop alarms
        syncClassAlarms(CLASS_SCHEDULE);
      }
    }
  } catch (err) {
    console.error('Fetch classes failed:', err);
    classList.innerHTML = '<div class="loading-placeholder" style="color: var(--danger)">Connection to server lost.</div>';
  }
}

// Render Classes List
function renderClasses() {
  if (CLASS_SCHEDULE.length === 0) {
    classList.innerHTML = '<div class="loading-placeholder">No classes in timetable yet. Click "+" to add one!</div>';
    return;
  }

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const now = new Date();
  const currentDayOfWeek = now.getDay(); // 0-6
  const currentHour = now.getHours();
  const currentMin = now.getMinutes();
  const currentTimeVal = currentHour * 60 + currentMin; // Current time in minutes since midnight

  // Filter list depending on active toggle
  let classesToShow = [];
  if (CURRENT_CLASS_VIEW === 'today') {
    classesToShow = CLASS_SCHEDULE.filter(c => c.dayOfWeek === currentDayOfWeek);
  } else {
    // Show all weekly classes, sorted by dayOfWeek then startTime
    classesToShow = [...CLASS_SCHEDULE];
  }

  if (classesToShow.length === 0) {
    const viewName = CURRENT_CLASS_VIEW === 'today' ? "today" : "this week";
    classList.innerHTML = `<div class="loading-placeholder">No classes scheduled for ${viewName}. Enjoy your free time!</div>`;
    return;
  }

  classList.innerHTML = '';

  classesToShow.forEach(c => {
    const item = document.createElement('div');
    item.className = 'class-item';
    item.dataset.id = c._id;

    // Check if this class is active right now
    let isActive = false;
    if (c.dayOfWeek === currentDayOfWeek) {
      const [startH, startM] = c.startTime.split(':').map(Number);
      const [endH, endM] = c.endTime.split(':').map(Number);
      const startTimeVal = startH * 60 + startM;
      const endTimeVal = endH * 60 + endM;
      
      if (currentTimeVal >= startTimeVal && currentTimeVal <= endTimeVal) {
        isActive = true;
        item.classList.add('active-class');
      }
    }

    item.innerHTML = `
      <div class="class-time-row">
        <span class="class-time">${c.startTime} - ${c.endTime}</span>
        <span class="class-day-label">${days[c.dayOfWeek]}${isActive ? ' • <span style="color: #34d399; font-weight: bold;">LIVE NOW</span>' : ''}</span>
      </div>
      <div class="class-name-row">
        <h3 class="class-name-text">${escapeHTML(c.className)}</h3>
        <button class="delete-action-btn" title="Delete Class">🗑️</button>
      </div>
      <div class="class-details">
        ${c.subject ? `<div class="detail-label"><span>Subj:</span> ${escapeHTML(c.subject)}</div>` : ''}
        ${c.room ? `<div class="detail-label"><span>Room:</span> ${escapeHTML(c.room)}</div>` : ''}
        ${c.instructor ? `<div class="detail-label"><span>Instr:</span> ${escapeHTML(c.instructor)}</div>` : ''}
      </div>
    `;

    // Hook Delete Button
    const deleteBtn = item.querySelector('.delete-action-btn');
    deleteBtn.addEventListener('click', async () => {
      if (confirm(`Delete class "${c.className}"?`)) {
        try {
          const res = await fetch(`${BACKEND_URL}/api/class/${c._id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${TOKEN}` }
          });
          if (res.ok) {
            fetchClasses();
          }
        } catch (err) {
          console.error(err);
        }
      }
    });

    classList.appendChild(item);
  });
}

// Add New Class
classForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const className = classNameInput.value.trim();
  const subject = classSubjectInput.value.trim();
  const room = classRoomInput.value.trim();
  const dayOfWeek = classDayInput.value;
  const startTime = classStartInput.value;
  const endTime = classEndInput.value;
  const instructor = classInstructorInput.value.trim();

  if (!className || dayOfWeek === '' || !startTime || !endTime) {
    alert('Please fill out all required fields.');
    return;
  }

  // Basic check: start time before end time
  const [startH, startM] = startTime.split(':').map(Number);
  const [endH, endM] = endTime.split(':').map(Number);
  if (startH > endH || (startH === endH && startM >= endM)) {
    alert('Start time must be earlier than end time.');
    return;
  }

  try {
    const res = await fetch(`${BACKEND_URL}/api/class`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        className,
        subject,
        room,
        dayOfWeek: Number(dayOfWeek),
        startTime,
        endTime,
        instructor
      })
    });

    if (res.ok) {
      // Reset and hide form
      classNameInput.value = '';
      classSubjectInput.value = '';
      classRoomInput.value = '';
      classDayInput.value = '';
      classStartInput.value = '';
      classEndInput.value = '';
      classInstructorInput.value = '';
      classFormContainer.classList.add('hidden');

      fetchClasses();
    }
  } catch (err) {
    console.error('Create class failed:', err);
  }
});


// 5. REMINDERS & CHROME ALARMS SYSTEM

// Clear and rebuild alarms for all registered classes
function syncClassAlarms(classes) {
  if (typeof chrome === 'undefined' || !chrome.alarms) {
    console.warn('Chrome Alarms API is not available (not running as extension).');
    return;
  }

  // Clear all existing dashboard alarms first
  chrome.alarms.clearAll(async () => {
    console.log('Cleared old class alarms. Rebuilding...');
    
    const now = new Date();
    const currentDay = now.getDay(); // 0-6

    classes.forEach(c => {
      try {
        // Calculate the next alarm trigger date (10 minutes before class startTime)
        const [startHour, startMin] = c.startTime.split(':').map(Number);
        
        let targetHour = startHour;
        let targetMin = startMin - 10;
        let dayAdjust = 0;

        if (targetMin < 0) {
          targetMin += 60;
          targetHour -= 1;
          if (targetHour < 0) {
            targetHour += 24;
            dayAdjust = -1; // Goes to previous day
          }
        }

        // Calculate days difference
        let diff = c.dayOfWeek - currentDay + dayAdjust;
        if (diff < 0) {
          diff += 7; // Wrap to next week
        }

        const alarmDate = new Date();
        alarmDate.setDate(alarmDate.getDate() + diff);
        alarmDate.setHours(targetHour, targetMin, 0, 0);

        // If target alarm time is already in the past for today, schedule it for 7 days later
        if (alarmDate.getTime() <= now.getTime()) {
          alarmDate.setDate(alarmDate.getDate() + 7);
        }

        // Format name string: class_alarm_[id]_[className]_[room]
        // We URI encode class names and rooms to make sure spaces don't break string splits
        const alarmName = `class_alarm_${c._id}_${encodeURIComponent(c.className)}_${encodeURIComponent(c.room || '')}`;

        // Create alarm in Chrome (fires once at the calculated timestamp, then repeats every 7 days)
        // 10080 minutes = 7 days
        chrome.alarms.create(alarmName, {
          when: alarmDate.getTime(),
          periodInMinutes: 10080
        });
        
        console.log(`Alarm scheduled for: "${c.className}" at ${alarmDate.toLocaleString()}`);
      } catch (err) {
        console.error(`Failed to schedule alarm for class: ${c.className}`, err);
      }
    });
  });
}


// 6. CLAUDE AI ASSISTANT CHAT

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const query = chatInput.value.trim();
  if (!query) return;

  // Append user message in UI
  appendChatMessage('user', query);
  chatInput.value = '';

  // Append to conversation history
  CHAT_HISTORY.push({ role: 'user', content: query });

  // Show typing status indicator
  aiStatus.textContent = 'Typing...';
  aiStatus.className = 'status-indicator typing';

  try {
    const clientTime = new Date().toISOString();
    const res = await fetch(`${BACKEND_URL}/api/ask-ai?clientTime=${encodeURIComponent(clientTime)}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TOKEN}`
      },
      body: JSON.stringify({
        messages: CHAT_HISTORY
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        const reply = data.data.content;
        appendChatMessage('assistant', reply);
        // Save reply in conversation history
        CHAT_HISTORY.push({ role: 'assistant', content: reply });
      } else {
        appendChatMessage('assistant', `Error: ${data.error || 'Unknown error occurred.'}`);
      }
    } else {
      appendChatMessage('assistant', "Could not reach Claude server. Check your connection or API key.");
    }
  } catch (err) {
    console.error('Claude request failed:', err);
    appendChatMessage('assistant', "Connection error. Make sure your local backend server is running.");
  } finally {
    // Restore status indicator
    aiStatus.textContent = 'Ready';
    aiStatus.className = 'status-indicator online';
  }
});

function appendChatMessage(role, content) {
  const msgDiv = document.createElement('div');
  msgDiv.className = `message ${role}`;
  msgDiv.innerHTML = `<div class="msg-bubble">${formatReplyText(content)}</div>`;
  
  chatMessages.appendChild(msgDiv);
  // Auto scroll to bottom
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Format newline symbols and basic markup safely
function formatReplyText(text) {
  // Convert standard markdown bold and linebreaks into clean HTML
  let escaped = escapeHTML(text);
  
  // Replace bold syntax **text** with <strong>text</strong>
  escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  // Replace linebreaks with <br> tags
  escaped = escaped.replace(/\n/g, '<br>');

  return escaped;
}


// Helper: Escape HTML strings to avoid security issues
function escapeHTML(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// 7. FILE IMPORT & SPEECH-TO-TEXT DICTATION SYSTEM

// Toggle Import Routine Form
if (importRoutineToggle) {
  importRoutineToggle.addEventListener('click', () => {
    importRoutineContainer.classList.toggle('hidden');
    // Hide standard add routine form if open
    routineFormContainer.classList.add('hidden');
  });
}

// Handle Import Tabs Switching (File vs Google Sheet)
let activeImportTab = 'file';

if (importTabFile && importTabSheet) {
  importTabFile.addEventListener('click', () => {
    activeImportTab = 'file';
    importTabFile.classList.add('active');
    importTabSheet.classList.remove('active');
    importPaneFile.classList.remove('hidden');
    importPaneSheet.classList.add('hidden');
  });

  importTabSheet.addEventListener('click', () => {
    activeImportTab = 'sheet';
    importTabSheet.classList.add('active');
    importTabFile.classList.remove('active');
    importPaneSheet.classList.remove('hidden');
    importPaneFile.classList.add('hidden');
  });
}

// Display selected file name
if (routineFileInput) {
  routineFileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      fileUploadStatus.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
      fileUploadStatus.classList.remove('hidden');
    } else {
      fileUploadStatus.classList.add('hidden');
    }
  });
}

// Handle Import Button click
if (processImportBtn) {
  processImportBtn.addEventListener('click', async () => {
    processImportBtn.disabled = true;
    processImportBtn.textContent = 'Analyzing and Importing...';
    fileUploadStatus.textContent = 'Processing document text...';
    fileUploadStatus.classList.remove('hidden');

    try {
      let payload = {};

      if (activeImportTab === 'sheet') {
        const url = sheetUrlInput.value.trim();
        if (!url) {
          alert('Please enter a Google Sheets URL.');
          processImportBtn.disabled = false;
          processImportBtn.textContent = 'Analyze & Import Tasks';
          return;
        }
        payload = { sheetUrl: url };
      } else {
        const file = routineFileInput.files[0];
        if (!file) {
          alert('Please select a file to import.');
          processImportBtn.disabled = false;
          processImportBtn.textContent = 'Analyze & Import Tasks';
          return;
        }

        // Read file contents as Base64
        const fileData = await readFileAsBase64(file);
        payload = {
          fileData,
          fileName: file.name,
          fileType: file.type
        };
      }

      // POST to backend API
      const res = await fetch(`${BACKEND_URL}/api/routine/import`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${TOKEN}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();

      if (res.ok && data.success) {
        alert(`Successfully imported ${data.data.length} routine items!`);
        importRoutineContainer.classList.add('hidden');
        sheetUrlInput.value = '';
        routineFileInput.value = '';
        fileUploadStatus.classList.add('hidden');
        // Refresh routine list
        fetchRoutines();
      } else {
        alert(data.error || 'Failed to analyze routines. Check your DeepSeek API configuration.');
      }
    } catch (err) {
      console.error('Import routines error:', err);
      alert('An error occurred during import. Make sure your local server is running.');
    } finally {
      processImportBtn.disabled = false;
      processImportBtn.textContent = 'Analyze & Import Tasks';
    }
  });
}

// Helper: Read File as Base64 string
function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const arrayBuffer = reader.result;
      const base64 = btoa(
        new Uint8Array(arrayBuffer)
          .reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
}

// Voice Typing (Speech-to-Text) using Web Speech API
function setupVoiceTyping(button, input) {
  if (!button || !input) return;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    button.style.display = 'none'; // Speech recognition not supported
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US'; // Default is English, but Speech API handles accent/input

  let isListening = false;

  button.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  });

  recognition.onstart = () => {
    isListening = true;
    button.classList.add('recording');
    input.placeholder = 'Listening... Speak now';
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    input.value = (input.value ? input.value + ' ' : '') + transcript;
  };

  recognition.onend = () => {
    isListening = false;
    button.classList.remove('recording');
    input.placeholder = input.id === 'chat-input' ? 'Ask DeepSeek...' : 'Routine Title (e.g. Read a book)';
  };

  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    isListening = false;
    button.classList.remove('recording');
  };
}

// Initialize Voice Dictation
document.addEventListener('DOMContentLoaded', () => {
  // Wait a small delay to make sure DOM elements are bound
  setTimeout(() => {
    setupVoiceTyping(document.getElementById('routine-mic-btn'), document.getElementById('routine-title'));
    setupVoiceTyping(document.getElementById('chat-mic-btn'), document.getElementById('chat-input'));
  }, 100);
});
